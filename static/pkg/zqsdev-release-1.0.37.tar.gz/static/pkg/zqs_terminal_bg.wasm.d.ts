/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const start: () => void;
export const wasm_bindgen__convert__closures_____invoke__h2d0576c870124f2c: (a: number, b: number, c: any) => void;
export const wasm_bindgen__closure__destroy__h2c18e785d6b7fc09: (a: number, b: number) => void;
export const wasm_bindgen__convert__closures_____invoke__h9512e0902abf4b9a: (a: number, b: number, c: any) => void;
export const wasm_bindgen__closure__destroy__h868cd167b54ca820: (a: number, b: number) => void;
export const wasm_bindgen__convert__closures_____invoke__h8f3b2327b584ca85: (a: number, b: number) => void;
export const wasm_bindgen__closure__destroy__h608893cd739fe0fa: (a: number, b: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
