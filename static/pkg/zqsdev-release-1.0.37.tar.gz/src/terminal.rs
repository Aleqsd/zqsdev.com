use crate::ai;
use crate::commands::{self, CommandAction, CommandError, PokemonAttemptOutcome};
use crate::renderer::{AchievementTier, AchievementView, Renderer, ScrollBehavior};
use crate::state::AppState;
use crate::telemetry::{self, CommandLogMode};
use crate::utils;
use gloo_timers::future::TimeoutFuture;
use serde::{Deserialize, Serialize};
use std::cell::{Cell, RefCell};
use std::rc::Rc;
use wasm_bindgen::closure::Closure;
use wasm_bindgen::JsCast;
use wasm_bindgen::JsValue;
use wasm_bindgen_futures::spawn_local;
use web_sys::HtmlElement;

pub type SharedState = Rc<RefCell<AppState>>;
pub type SharedRenderer = Rc<Renderer>;

pub struct Terminal {
    state: SharedState,
    renderer: SharedRenderer,
}

pub enum HistoryDirection {
    Older,
    Newer,
}

const WELCOME_TYPE_DELAY_MS: u32 = 18;
const AI_HELP_COMMAND: &str = "help";
const AI_QUIT_COMMAND: &str = "quit";
const AI_QUIT_LABEL: &str = "Quit AI";
const AI_STATUS_ACTIVE: &str = "AI Mode: Activated";
const AI_STATUS_DEACTIVATED: &str = "AI Mode: Deactivated";
const AI_STATUS_BUSY: &str = "AI Mode: Activated — Synthesizing…";
const AI_ACTIVATED_INFO: &str =
    "🤖 AI Mode activated. Ask anything about Alexandre DO-O ALMEIDA's profile.";
const AI_DEACTIVATED_INFO: &str = "📟 AI Mode deactivated. Classic terminal helpers restored.";
const AI_HELP_MESSAGE: &str = "🤖 AI Mode help:\nYou're chatting with an assistant that uses Alexandre's career knowledge: experience, projects, publications and testimonials.\nAsk follow-up questions; the last 3 exchanges are remembered in this tab. Type `quit` to exit and clear this conversation.";
const AI_DATA_LOADING: &str = "AI knowledge base still loading. Please try again shortly.";
const BOOT_SEQUENCE_MESSAGE: &str = "Welcome to the ZQSDev interactive terminal!";
const WELCOME_GUIDANCE_LINES: [&str; 2] = [
    "Type `help` to view all available commands.",
    "Use the quick actions below to jump to key sections instantly.",
];
const TV_OFF_COMMAND: &str = "rm -rf";
const TV_OFF_WARNING: &str = "⚠️ `rm -rf` sequence detected. Powering down terminal…";
const KONAMI_CODE: [&str; 10] = [
    "ArrowUp",
    "ArrowUp",
    "ArrowDown",
    "ArrowDown",
    "ArrowLeft",
    "ArrowRight",
    "ArrowLeft",
    "ArrowRight",
    "b",
    "a",
];
const KONAMI_ALERT: &str = "🕹️ Cheat code accepted! Goku is charging a Kamehameha!";
const KAMEHAMEHA_MEDIA_HTML: &str = r#"
<figure class="konami-kamehameha">
    <img
        class="konami-kamehameha__video"
        src="./effects/kamehameha.gif"
        alt="Goku unleashes a Kamehameha beam"
        loading="lazy"
    >
    <audio
        class="konami-kamehameha__audio"
        src="./effects/kamehameha.mp3"
        preload="auto"
        autoplay
        playsinline
    ></audio>
</figure>
"#;
const GOKU_FINISHER_HTML: &str =
    r#"<div class="konami-message konami-message--goku">Goku: "KAMEHAMEHA!" 💥</div>"#;
const TERMINAL_EXPLODED_HTML: &str = r#"<div class="konami-message konami-message--terminal">💥 The terminal has exploded. Refresh the page to revive it.</div>"#;
const KAMEHAMEHA_PROMPT_LABEL: &str = "⚡ KI>$";
const ACHIEVEMENT_SHAW_TITLE: &str = "Shaw!";
const ACHIEVEMENT_SHAW_DESCRIPTION: &str = "Could she be... a Hunter?";
const ACHIEVEMENT_POKEMON_TITLE: &str = "Who's that Pokemon?";
const ACHIEVEMENT_POKEMON_DESCRIPTION: &str = "It's Pikachu!";
const ACHIEVEMENT_COOKIE_TITLE: &str = "Cookie Storm!";
const ACHIEVEMENT_COOKIE_DESCRIPTION: &str = "Summoned the sweetest downpour.";
const ACHIEVEMENT_KONAMI_TITLE: &str = "Kamehameha!";
const ACHIEVEMENT_KONAMI_DESCRIPTION: &str = "And this... is to go even further beyond!";
const ACHIEVEMENT_SHUTDOWN_TITLE: &str = "AAAAAAAAAAAAAH";
const ACHIEVEMENT_SHUTDOWN_DESCRIPTION: &str = "Why would you do that?!";
const ACHIEVEMENT_PLATINUM_TITLE: &str = "Platinum Trophy";
const ACHIEVEMENT_PLATINUM_DESCRIPTION: &str = "Unlocked every Easter egg in the terminal.";
const ACHIEVEMENTS_STORAGE_KEY: &str = "zqs_terminal_achievements";
const ACHIEVEMENTS_STORAGE_VERSION: &str = env!("CARGO_PKG_VERSION");
const ACHIEVEMENT_SHAW_HINT: &str = "Hornet shouts can be heard in the terminal.";
const ACHIEVEMENT_POKEMON_HINT: &str = "Gotta catch 'em all!";
const ACHIEVEMENT_COOKIE_HINT: &str = "Tap into the cookie zone.";
const ACHIEVEMENT_KONAMI_HINT: &str = "Konami";
const ACHIEVEMENT_SHUTDOWN_HINT: &str = "Why would you remove my files?";
const ACHIEVEMENT_PLATINUM_HINT: &str = "Claim every other Easter egg to reveal the rarest trophy.";

impl Terminal {
    pub fn new(state: SharedState, renderer: SharedRenderer) -> Self {
        Self { state, renderer }
    }

    pub fn initialize(&self) -> Result<(), JsValue> {
        let (prompt_label, input_buffer, ai_mode) = {
            let state = self.state.borrow();
            (
                state.prompt_label.clone(),
                state.input_buffer.clone(),
                state.ai_mode,
            )
        };

        self.renderer.set_prompt_label(&prompt_label);
        self.renderer.update_input(&input_buffer);
        self.refresh_suggestions();
        self.renderer.apply_ai_mode(ai_mode)?;
        self.renderer.focus_terminal();
        Ok(())
    }

    pub fn focus(&self) {
        if self.input_disabled() {
            return;
        }
        self.renderer.focus_terminal();
    }

    pub fn restore_achievements_from_storage(&self) {
        if let Err(err) = self.try_restore_achievements_from_storage() {
            utils::log(&format!(
                "Failed to restore achievements state from storage: {:?}",
                err
            ));
        }
    }

    pub fn open_achievements_modal(&self) -> Result<(), JsValue> {
        let achievements = self.collect_achievement_views();
        let spoilers_enabled = self.achievements_spoilers_enabled();
        self.renderer
            .show_achievements_modal(&achievements, spoilers_enabled)?;
        {
            let mut state = self.state.borrow_mut();
            state.achievements_modal_open = true;
        }
        Ok(())
    }

    pub fn close_achievements_modal(&self) -> Result<(), JsValue> {
        {
            let mut state = self.state.borrow_mut();
            state.achievements_modal_open = false;
        }
        self.renderer.hide_achievements_modal()
    }

    pub fn toggle_achievements_spoilers(&self) -> Result<(), JsValue> {
        {
            let mut state = self.state.borrow_mut();
            state.achievements_spoilers_enabled = !state.achievements_spoilers_enabled;
        }
        self.persist_achievements_state();
        self.refresh_achievements_modal_if_visible()
    }

    pub fn reset_achievements(&self) -> Result<(), JsValue> {
        {
            let mut state = self.state.borrow_mut();
            state.achievement_shaw_unlocked = false;
            state.achievement_pokemon_unlocked = false;
            state.achievement_cookie_unlocked = false;
            state.achievement_konami_unlocked = false;
            state.achievement_shutdown_unlocked = false;
            state.achievement_platinum_unlocked = false;
            state.achievements_spoilers_enabled = false;
            state.konami_triggered = false;
            state.konami_index = 0;
            state.pokemon_capture_chance = 1;
        }
        if let Err(err) = self.clear_achievements_storage() {
            utils::log(&format!(
                "Failed to clear achievements storage during reset: {:?}",
                err
            ));
        }
        self.persist_achievements_state();
        self.refresh_achievements_modal_if_visible()
    }

    pub fn handle_escape(&self) {
        if self.close_achievements_modal_if_open() {
            return;
        }
        self.clear_input();
    }

    pub fn overwrite_input(&self, value: &str) {
        if self.input_disabled() {
            return;
        }
        {
            let mut state = self.state.borrow_mut();
            state.input_buffer = value.to_string();
            state.history_index = None;
        }
        self.refresh_input();
        self.refresh_suggestions();
    }

    pub fn push_system_message(&self, message: &str) {
        let _ = self
            .renderer
            .append_info_line(message, ScrollBehavior::Bottom);
    }

    pub fn submit_command(&self) -> Result<(), JsValue> {
        if self.input_disabled() {
            return Ok(());
        }
        let input = {
            let state = self.state.borrow();
            state.input_buffer.clone()
        };

        let display_line = input.clone();
        let mut state_mut = self.state.borrow_mut();
        let prompt_label = state_mut.prompt_label.clone();
        let trimmed = input.trim().to_string();
        state_mut.remember_command(&trimmed);
        state_mut.input_buffer.clear();
        drop(state_mut);

        self.refresh_input();
        self.refresh_suggestions();

        let ai_mode_active = self.ai_mode_active();
        let command_scroll = ScrollBehavior::Anchor;
        self.renderer.append_spacer_line(ScrollBehavior::None)?;
        self.renderer
            .append_command(&prompt_label, &display_line, command_scroll)?;

        if trimmed.is_empty() {
            return Ok(());
        }

        if !ai_mode_active {
            telemetry::log_command_submission(&trimmed, CommandLogMode::Classic);
        }

        if Self::is_shutdown_command(&trimmed) {
            let celebrate = {
                let mut state = self.state.borrow_mut();
                state.unlock_shutdown_protocol()
            };
            if celebrate {
                self.trigger_achievement_popup(
                    ACHIEVEMENT_SHUTDOWN_TITLE,
                    ACHIEVEMENT_SHUTDOWN_DESCRIPTION,
                    AchievementTier::Standard,
                )?;
                self.finalize_achievement_unlock()?;
            }

            self.trigger_shutdown_sequence(1000)?;
            return Ok(());
        }

        if ai_mode_active {
            return self.handle_ai_mode_submission(trimmed);
        }

        let args: Vec<&str> = trimmed.split_whitespace().collect();
        let command = args.first().cloned().unwrap_or_default();
        let extra = if args.is_empty() { &[][..] } else { &args[1..] };

        let action = {
            let state = self.state.borrow();
            commands::execute(command, &state, extra)
        };

        let output_scroll = ScrollBehavior::Bottom;

        match action {
            Ok(CommandAction::Output(text)) => {
                self.renderer.append_output_text(&text, output_scroll)?;
            }
            Ok(CommandAction::OutputHtml(html)) => {
                self.renderer.append_output_html(&html, output_scroll)?;
            }
            Ok(CommandAction::ShawEffect) => {
                self.play_shaw_effect()?;
            }
            Ok(CommandAction::PokemonAttempt(outcome)) => {
                self.play_pokemon_attempt(&outcome, output_scroll)?;
            }
            Ok(CommandAction::CookieClicker) => {
                self.start_cookie_clicker(output_scroll)?;
            }
            Ok(CommandAction::Clear) => {
                self.renderer.clear_output();
            }
            Ok(CommandAction::Download(url)) => {
                utils::open_link(&url);
                let confirmation = format!("Opening résumé at {url}");
                self.renderer
                    .append_info_line(&confirmation, output_scroll)?;
            }
            Err(CommandError::NotFound { command }) => {
                self.handle_unknown_command(&command)?;
            }
            Err(CommandError::Message(message)) => {
                self.renderer.append_output_text(&message, output_scroll)?;
            }
        }

        Ok(())
    }

    pub fn process_konami_key(&self, key: &str) -> Result<bool, JsValue> {
        let Some(normalized) = Self::normalize_konami_key(key) else {
            self.reset_konami_progress();
            return Ok(false);
        };

        let triggered = {
            let mut state = self.state.borrow_mut();
            if state.konami_triggered {
                false
            } else if KONAMI_CODE[state.konami_index] == normalized {
                state.konami_index += 1;
                if state.konami_index == KONAMI_CODE.len() {
                    state.konami_index = 0;
                    state.konami_triggered = true;
                    true
                } else {
                    false
                }
            } else {
                state.konami_index = if normalized == KONAMI_CODE[0] { 1 } else { 0 };
                false
            }
        };

        if triggered {
            let celebrate = {
                let mut state = self.state.borrow_mut();
                state.unlock_konami_secret()
            };
            self.start_kamehameha_sequence()?;
            if celebrate {
                self.trigger_achievement_popup(
                    ACHIEVEMENT_KONAMI_TITLE,
                    ACHIEVEMENT_KONAMI_DESCRIPTION,
                    AchievementTier::Standard,
                )?;
                self.finalize_achievement_unlock()?;
            }
            return Ok(true);
        }

        Ok(false)
    }

    pub fn toggle_ai_mode(&self) -> Result<(), JsValue> {
        let next = !self.ai_mode_active();
        self.update_ai_mode(next, true)
    }

    pub fn activate_ai_mode(&self) -> Result<(), JsValue> {
        if self.ai_mode_active() {
            return Ok(());
        }
        self.update_ai_mode(true, true)
    }

    fn handle_unknown_command(&self, command: &str) -> Result<(), JsValue> {
        let message =
            format!("Command not found: `{command}`\nType `help` to list available commands.");
        let info_scroll = ScrollBehavior::Bottom;
        self.renderer
            .append_output_text(&message, info_scroll.clone())?;
        let html = r#"Need a hand? <button type="button" class="ai-mode-cta" data-action="activate-ai-mode">Ask the AI assistant</button>"#;
        self.renderer.append_info_html(html, info_scroll)?;
        Ok(())
    }

    pub fn clear_input(&self) {
        if self.input_disabled() {
            return;
        }
        {
            let mut state = self.state.borrow_mut();
            state.input_buffer.clear();
            state.history_index = None;
        }
        self.refresh_input();
        self.refresh_suggestions();
    }

    pub fn append_character(&self, value: &str) {
        self.append_text(value);
    }

    pub fn append_text(&self, value: &str) {
        if self.input_disabled() || value.is_empty() {
            return;
        }
        {
            let mut state = self.state.borrow_mut();
            state.input_buffer.push_str(value);
            state.history_index = None;
        }
        self.refresh_input();
        self.refresh_suggestions();
    }

    pub fn delete_last_character(&self) {
        if self.input_disabled() {
            return;
        }
        {
            let mut state = self.state.borrow_mut();
            state.input_buffer.pop();
            state.history_index = None;
        }
        self.refresh_input();
        self.refresh_suggestions();
    }

    pub fn navigate_history(&self, direction: HistoryDirection) {
        if self.input_disabled() {
            return;
        }
        let new_buffer = {
            let mut state = self.state.borrow_mut();
            select_history_entry(&mut state, direction)
        };

        if let Some(buffer) = new_buffer {
            self.renderer.update_input(&buffer);
            self.refresh_suggestions();
        }
    }

    pub fn autocomplete(&self) {
        if self.input_disabled() {
            return;
        }
        let suggestion = {
            let state = self.state.borrow();
            commands::autocomplete(&state.input_buffer).map(|value| value.to_string())
        };

        if let Some(text) = suggestion {
            {
                let mut state = self.state.borrow_mut();
                state.input_buffer = text;
            }
            self.refresh_input();
            self.refresh_suggestions();
        }
    }

    pub fn execute_suggestion(&self, command: &str) -> Result<(), JsValue> {
        if self.input_disabled() {
            return Ok(());
        }
        {
            let mut state = self.state.borrow_mut();
            state.input_buffer = command.to_string();
            state.history_index = None;
        }
        self.refresh_input();
        self.submit_command()
    }

    pub fn on_data_ready(&self) -> Result<(), JsValue> {
        let profile_name = {
            let state = self.state.borrow();
            let name = state.data.as_ref().map(|data| data.profile.name.clone());
            name
        };

        let renderer = Rc::clone(&self.renderer);
        spawn_local(async move {
            if let Err(err) = renderer
                .type_output_text(BOOT_SEQUENCE_MESSAGE, WELCOME_TYPE_DELAY_MS)
                .await
            {
                utils::log(&format!("Failed to animate welcome message: {:?}", err));
                if let Err(err) =
                    renderer.append_output_text(BOOT_SEQUENCE_MESSAGE, ScrollBehavior::Bottom)
                {
                    utils::log(&format!(
                        "Failed to render welcome message fallback: {:?}",
                        err
                    ));
                }
            }

            if let Some(name) = profile_name {
                let profile_line = profile_loaded_line(&name);
                if let Err(err) = renderer.append_output_text(&profile_line, ScrollBehavior::Bottom)
                {
                    utils::log(&format!(
                        "Failed to append profile line `{profile_line}`: {:?}",
                        err
                    ));
                }
            }

            for guidance in WELCOME_GUIDANCE_LINES {
                if let Err(err) = renderer.append_info_line(guidance, ScrollBehavior::Bottom) {
                    utils::log(&format!(
                        "Failed to append guidance line `{guidance}`: {:?}",
                        err
                    ));
                }
            }

            let ai_cta_html = r#"Prefer to talk with an AI? <button type="button" class="ai-mode-cta" data-action="activate-ai-mode">Ask the AI assistant</button>"#;
            if let Err(err) = renderer.append_info_html(ai_cta_html, ScrollBehavior::Bottom) {
                utils::log(&format!(
                    "Failed to append AI assistant call-to-action: {:?}",
                    err
                ));
            }
        });

        Ok(())
    }

    fn trigger_shutdown_sequence(&self, delay_ms: u32) -> Result<(), JsValue> {
        if self.ensure_input_disabled() {
            return Ok(());
        }

        self.renderer.disable_prompt_input()?;
        self.renderer.update_input("");
        self.renderer
            .render_suggestions(std::iter::empty::<(String, String)>());

        let renderer = Rc::clone(&self.renderer);
        spawn_local(async move {
            TimeoutFuture::new(delay_ms).await;

            if let Err(err) = renderer.append_info_line(TV_OFF_WARNING, ScrollBehavior::Bottom) {
                utils::log(&format!(
                    "Failed to append shutdown warning line after delay: {:?}",
                    err
                ));
                return;
            }

            if let Err(err) = renderer.play_tv_shutdown_animation() {
                utils::log(&format!(
                    "Failed to play TV shutdown animation after delay: {:?}",
                    err
                ));
            }
        });
        Ok(())
    }

    fn play_pokemon_attempt(
        &self,
        outcome: &PokemonAttemptOutcome,
        behavior: ScrollBehavior,
    ) -> Result<(), JsValue> {
        {
            let mut state = self.state.borrow_mut();
            state.set_pokemon_capture_chance(outcome.next_chance);
        }

        let chance_message = format!(
            "You have a {chance}% chance of catching Pikachu!",
            chance = outcome.current_chance
        );
        self.renderer
            .append_output_text(&chance_message, behavior)?;

        let attempt_effect = self.renderer.render_pokemon_capture_attempt()?;
        self.dismiss_pokemon_effect_after_delay(&attempt_effect, 2000);

        if outcome.success {
            self.renderer
                .append_info_line("⚡️ Poké Ball shakes… success!", ScrollBehavior::Bottom)?;
            let celebrate = {
                let mut state = self.state.borrow_mut();
                state.unlock_pokemon_master()
            };
            if celebrate {
                self.trigger_achievement_popup(
                    ACHIEVEMENT_POKEMON_TITLE,
                    ACHIEVEMENT_POKEMON_DESCRIPTION,
                    AchievementTier::Standard,
                )?;
                self.finalize_achievement_unlock()?;
            }
            let success_effect = self.renderer.render_pokemon_capture_success()?;
            self.dismiss_pokemon_effect_after_delay(&success_effect, 5000);
            self.renderer.append_info_line(
                "Pikachu was caught! Congratulations!",
                ScrollBehavior::Bottom,
            )?;
        } else {
            self.renderer
                .append_info_line("Oh you failed, try again!", ScrollBehavior::Bottom)?;
            let state = self.state.borrow();
            let next = state.pokemon_capture_chance();
            drop(state);
            if next > outcome.current_chance {
                let encouragement =
                    format!("Your next capture chance rises to {next}%.", next = next);
                self.renderer
                    .append_info_line(&encouragement, ScrollBehavior::Bottom)?;
            }
        }

        Ok(())
    }

    fn start_cookie_clicker(&self, behavior: ScrollBehavior) -> Result<(), JsValue> {
        let _ = behavior;
        self.renderer.append_info_line(
            "🍪 Cookie protocol initiated! Click the cookie to reach 100 and unlock the secret.",
            ScrollBehavior::Bottom,
        )?;

        let view = self.renderer.render_cookie_clicker()?;
        view.prompt
            .set_text_content(Some(Self::cookie_prompt_for(0)));
        Self::apply_cookie_counter_tier(&view.counter, 0);
        Self::apply_cookie_wrapper_state(&view.wrapper, 0);

        let state = Rc::clone(&self.state);
        let renderer = Rc::clone(&self.renderer);

        let counter_cell = Rc::new(Cell::new(0u32));
        let finished = Rc::new(Cell::new(false));

        let counter_el = view.counter.clone();
        let prompt_el = view.prompt.clone();
        let wrapper_el = view.wrapper.clone();
        let line_el = view.line.clone();
        let button_el = view.button.clone();

        let click_handler = {
            let state = Rc::clone(&state);
            let renderer = Rc::clone(&renderer);
            let counter_cell = Rc::clone(&counter_cell);
            let finished = Rc::clone(&finished);
            Closure::wrap(Box::new(move |event: web_sys::MouseEvent| {
                event.prevent_default();
                if finished.get() {
                    return;
                }
                let next = counter_cell.get().saturating_add(1).min(100);
                counter_cell.set(next);

                let label = format!("{next} / 100");
                counter_el.set_text_content(Some(&label));
                Terminal::apply_cookie_counter_tier(&counter_el, next);
                Terminal::apply_cookie_wrapper_state(&wrapper_el, next);
                prompt_el.set_text_content(Some(Terminal::cookie_prompt_for(next)));

                if next == 100 {
                    finished.set(true);
                    let _ = button_el.set_attribute("disabled", "true");
                    Terminal::celebrate_cookie_unlock(Rc::clone(&state), Rc::clone(&renderer));
                    Terminal::launch_cookie_rain_sequence(
                        Rc::clone(&renderer),
                        line_el.clone(),
                        Some(wrapper_el.clone()),
                    );
                }
            }) as Box<dyn FnMut(_)>)
        };

        view.button
            .add_event_listener_with_callback("click", click_handler.as_ref().unchecked_ref())?;
        click_handler.forget();

        Ok(())
    }

    fn dismiss_pokemon_effect_after_delay(&self, element: &HtmlElement, delay_ms: u32) {
        let renderer = Rc::clone(&self.renderer);
        let element = element.clone();
        spawn_local(async move {
            TimeoutFuture::new(delay_ms).await;

            if let Err(err) = element.set_attribute("data-state", "hiding") {
                utils::log(&format!(
                    "Failed to mark Pokémon effect for dismissal: {:?}",
                    err
                ));
                return;
            }

            TimeoutFuture::new(260).await;

            if let Err(err) = renderer.remove_effect(&element) {
                utils::log(&format!(
                    "Failed to remove Pokémon effect element: {:?}",
                    err
                ));
            }
        });
    }

    fn trigger_achievement_popup(
        &self,
        title: &str,
        description: &str,
        tier: AchievementTier,
    ) -> Result<(), JsValue> {
        let toast = self
            .renderer
            .render_achievement_toast(title, description, tier)?;
        Self::schedule_toast_dismissal(Rc::clone(&self.renderer), toast, 5200);
        Ok(())
    }

    fn finalize_achievement_unlock(&self) -> Result<(), JsValue> {
        self.sync_platinum_unlock()?;
        self.persist_achievements_state();
        self.refresh_achievements_modal_if_visible()
    }

    fn sync_platinum_unlock(&self) -> Result<(), JsValue> {
        let celebrate = {
            let mut state = self.state.borrow_mut();
            state.unlock_platinum_trophy()
        };
        if celebrate {
            self.trigger_achievement_popup(
                ACHIEVEMENT_PLATINUM_TITLE,
                ACHIEVEMENT_PLATINUM_DESCRIPTION,
                AchievementTier::Platinum,
            )?;
        }
        Ok(())
    }

    fn sync_platinum_unlock_shared(state: &SharedState, renderer: &SharedRenderer) {
        let celebrate = {
            let mut state_mut = state.borrow_mut();
            state_mut.unlock_platinum_trophy()
        };
        if !celebrate {
            return;
        }

        match renderer.render_achievement_toast(
            ACHIEVEMENT_PLATINUM_TITLE,
            ACHIEVEMENT_PLATINUM_DESCRIPTION,
            AchievementTier::Platinum,
        ) {
            Ok(toast) => {
                Self::schedule_toast_dismissal(Rc::clone(renderer), toast, 5200);
            }
            Err(err) => {
                utils::log(&format!(
                    "Failed to display platinum achievement toast: {:?}",
                    err
                ));
            }
        }
    }

    fn schedule_toast_dismissal(renderer: SharedRenderer, toast: HtmlElement, delay_ms: u32) {
        spawn_local(async move {
            TimeoutFuture::new(delay_ms).await;

            if let Err(err) = toast.set_attribute("data-state", "hiding") {
                utils::log(&format!(
                    "Failed to mark achievement toast for dismissal: {:?}",
                    err
                ));
                return;
            }

            TimeoutFuture::new(320).await;

            if let Err(err) = renderer.remove_effect(&toast) {
                utils::log(&format!(
                    "Failed to remove achievement toast element: {:?}",
                    err
                ));
            }
        });
    }

    fn refresh_achievements_modal_if_visible(&self) -> Result<(), JsValue> {
        Self::refresh_achievements_modal_for_shared(&self.state, &self.renderer)
    }

    fn collect_achievement_views(&self) -> Vec<AchievementView> {
        let state = self.state.borrow();
        Self::build_achievement_views(&state)
    }

    fn refresh_achievements_modal_for_shared(
        state: &SharedState,
        renderer: &SharedRenderer,
    ) -> Result<(), JsValue> {
        let (should_refresh, spoilers_enabled) = {
            let state_ref = state.borrow();
            (
                state_ref.achievements_modal_open,
                state_ref.achievements_spoilers_enabled,
            )
        };
        if !should_refresh {
            return Ok(());
        }
        let achievements = {
            let state_ref = state.borrow();
            Self::build_achievement_views(&state_ref)
        };
        renderer.show_achievements_modal(&achievements, spoilers_enabled)
    }

    fn build_achievement_views(state: &AppState) -> Vec<AchievementView> {
        let mut unlocked = Vec::new();
        let mut locked = Vec::new();

        let entries = [
            (
                state.achievement_shaw_unlocked,
                ACHIEVEMENT_SHAW_TITLE,
                ACHIEVEMENT_SHAW_DESCRIPTION,
                ACHIEVEMENT_SHAW_HINT,
                AchievementTier::Standard,
            ),
            (
                state.achievement_pokemon_unlocked,
                ACHIEVEMENT_POKEMON_TITLE,
                ACHIEVEMENT_POKEMON_DESCRIPTION,
                ACHIEVEMENT_POKEMON_HINT,
                AchievementTier::Standard,
            ),
            (
                state.achievement_cookie_unlocked,
                ACHIEVEMENT_COOKIE_TITLE,
                ACHIEVEMENT_COOKIE_DESCRIPTION,
                ACHIEVEMENT_COOKIE_HINT,
                AchievementTier::Standard,
            ),
            (
                state.achievement_konami_unlocked,
                ACHIEVEMENT_KONAMI_TITLE,
                ACHIEVEMENT_KONAMI_DESCRIPTION,
                ACHIEVEMENT_KONAMI_HINT,
                AchievementTier::Standard,
            ),
            (
                state.achievement_shutdown_unlocked,
                ACHIEVEMENT_SHUTDOWN_TITLE,
                ACHIEVEMENT_SHUTDOWN_DESCRIPTION,
                ACHIEVEMENT_SHUTDOWN_HINT,
                AchievementTier::Standard,
            ),
            (
                state.achievement_platinum_unlocked,
                ACHIEVEMENT_PLATINUM_TITLE,
                ACHIEVEMENT_PLATINUM_DESCRIPTION,
                ACHIEVEMENT_PLATINUM_HINT,
                AchievementTier::Platinum,
            ),
        ];

        for (is_unlocked, title, description, hint, tier) in entries {
            let view = AchievementView::new(title, description, hint, is_unlocked, tier);
            if is_unlocked {
                unlocked.push(view);
            } else {
                locked.push(view);
            }
        }

        unlocked.extend(locked);
        unlocked
    }

    fn close_achievements_modal_if_open(&self) -> bool {
        let is_open = {
            let state = self.state.borrow();
            state.achievements_modal_open
        };
        if !is_open {
            return false;
        }
        if let Err(err) = self.close_achievements_modal() {
            utils::log(&format!("Failed to close achievements modal: {:?}", err));
        }
        true
    }

    fn achievements_spoilers_enabled(&self) -> bool {
        let state = self.state.borrow();
        state.achievements_spoilers_enabled
    }

    fn persist_achievements_state(&self) {
        Self::persist_achievements_snapshot_shared(&self.state);
    }

    fn try_restore_achievements_from_storage(&self) -> Result<(), JsValue> {
        let Some(window) = utils::window() else {
            return Ok(());
        };
        let storage = match window.local_storage()? {
            Some(storage) => storage,
            None => return Ok(()),
        };
        let raw = match storage.get_item(ACHIEVEMENTS_STORAGE_KEY)? {
            Some(value) => value,
            None => return Ok(()),
        };
        let data: StoredAchievements = match serde_json::from_str(&raw) {
            Ok(data) => data,
            Err(err) => {
                utils::log(&format!("Discarding corrupt achievements cache: {err}"));
                let _ = storage.remove_item(ACHIEVEMENTS_STORAGE_KEY);
                return Ok(());
            }
        };
        if data.version != ACHIEVEMENTS_STORAGE_VERSION {
            let _ = storage.remove_item(ACHIEVEMENTS_STORAGE_KEY);
            return Ok(());
        }
        {
            let mut state = self.state.borrow_mut();
            state.achievement_shaw_unlocked = data.shaw;
            state.achievement_pokemon_unlocked = data.pokemon;
            state.achievement_cookie_unlocked = data.cookie;
            state.achievement_konami_unlocked = data.konami;
            state.achievement_shutdown_unlocked = data.shutdown;
            state.achievement_platinum_unlocked =
                data.platinum || state.all_base_achievements_unlocked();
            state.achievements_spoilers_enabled = data.spoilers_enabled;
        }
        Ok(())
    }

    fn clear_achievements_storage(&self) -> Result<(), JsValue> {
        let Some(window) = utils::window() else {
            return Ok(());
        };
        let storage = match window.local_storage()? {
            Some(storage) => storage,
            None => return Ok(()),
        };
        storage.remove_item(ACHIEVEMENTS_STORAGE_KEY)?;
        Ok(())
    }

    fn persist_achievements_snapshot_shared(state: &SharedState) {
        let payload = {
            let state_ref = state.borrow();
            Self::build_achievements_payload(&state_ref)
        };
        if let Err(err) = Self::write_achievements_payload(&payload) {
            utils::log(&format!("Failed to persist achievements state: {:?}", err));
        }
    }

    fn build_achievements_payload(state: &AppState) -> StoredAchievements {
        StoredAchievements {
            version: ACHIEVEMENTS_STORAGE_VERSION.to_string(),
            shaw: state.achievement_shaw_unlocked,
            pokemon: state.achievement_pokemon_unlocked,
            cookie: state.achievement_cookie_unlocked,
            konami: state.achievement_konami_unlocked,
            shutdown: state.achievement_shutdown_unlocked,
            platinum: state.achievement_platinum_unlocked,
            spoilers_enabled: state.achievements_spoilers_enabled,
        }
    }

    fn write_achievements_payload(payload: &StoredAchievements) -> Result<(), JsValue> {
        let Some(window) = utils::window() else {
            return Ok(());
        };
        let storage = match window.local_storage()? {
            Some(storage) => storage,
            None => return Ok(()),
        };
        let serialized = serde_json::to_string(payload).map_err(|err| {
            JsValue::from_str(&format!("Failed to serialize achievements payload: {err}"))
        })?;
        storage.set_item(ACHIEVEMENTS_STORAGE_KEY, &serialized)?;
        Ok(())
    }

    fn celebrate_cookie_unlock(state: SharedState, renderer: SharedRenderer) {
        let celebrate = {
            let mut state_mut = state.borrow_mut();
            state_mut.unlock_cookie_rain()
        };
        if !celebrate {
            return;
        }

        match renderer.render_achievement_toast(
            ACHIEVEMENT_COOKIE_TITLE,
            ACHIEVEMENT_COOKIE_DESCRIPTION,
            AchievementTier::Standard,
        ) {
            Ok(toast) => {
                Self::schedule_toast_dismissal(Rc::clone(&renderer), toast, 5200);
            }
            Err(err) => {
                utils::log(&format!(
                    "Failed to display cookie achievement toast: {:?}",
                    err
                ));
            }
        }

        Self::sync_platinum_unlock_shared(&state, &renderer);
        Self::persist_achievements_snapshot_shared(&state);

        if let Err(err) = Self::refresh_achievements_modal_for_shared(&state, &renderer) {
            utils::log(&format!(
                "Failed to refresh achievements modal after cookie unlock: {:?}",
                err
            ));
        }
    }

    fn launch_cookie_rain_sequence(
        renderer: SharedRenderer,
        line: HtmlElement,
        wrapper: Option<HtmlElement>,
    ) {
        if let Err(err) =
            renderer.append_info_line("🍪 100/100! Cookie storm incoming!", ScrollBehavior::Bottom)
        {
            utils::log(&format!("Failed to announce cookie celebration: {:?}", err));
        }

        let rain = match renderer.render_cookie_rain(120) {
            Ok(layer) => Some(layer),
            Err(err) => {
                utils::log(&format!("Failed to render cookie rain: {:?}", err));
                None
            }
        };

        if let Some(wrapper_el) = wrapper.as_ref() {
            if let Err(err) = wrapper_el.class_list().add_1("cookie-clicker--celebrating") {
                utils::log(&format!(
                    "Failed to flag cookie wrapper celebration: {:?}",
                    err
                ));
            }
        }

        let cleanup_renderer = Rc::clone(&renderer);
        let cleanup_line = line.clone();
        let cleanup_wrapper = wrapper.clone();
        let cleanup_rain = rain.clone();
        spawn_local(async move {
            TimeoutFuture::new(5000).await;

            if let Some(wrapper_el) = cleanup_wrapper {
                let _ = wrapper_el.set_attribute("data-state", "hiding");
            }
            if let Err(err) = cleanup_line.set_attribute("data-state", "hiding") {
                utils::log(&format!(
                    "Failed to mark cookie clicker line for dismissal: {:?}",
                    err
                ));
            }
            if let Some(rain_layer) = cleanup_rain.as_ref() {
                let _ = rain_layer.set_attribute("data-state", "hiding");
            }

            TimeoutFuture::new(320).await;

            if let Some(rain_layer) = cleanup_rain {
                if let Err(err) = cleanup_renderer.remove_effect(&rain_layer) {
                    utils::log(&format!("Failed to remove cookie rain layer: {:?}", err));
                }
            }
            if let Err(err) = cleanup_renderer.remove_effect(&cleanup_line) {
                utils::log(&format!("Failed to remove cookie clicker line: {:?}", err));
            }
        });
    }

    fn cookie_prompt_for(count: u32) -> &'static str {
        match count {
            0 => "Click the cookie to start baking the sweetest storm.",
            1..=24 => "Nice! Keep tapping to build up momentum.",
            25..=49 => "The oven is warming up. Stay on the cookie!",
            50..=74 => "Halfway there—the kitchen smells amazing!",
            75..=89 => "Crumbs are flying! Don't stop now!",
            90..=99 => "Critical cookie mass! Just a few more taps!",
            _ => "Sweet victory! Enjoy that cookie rain!",
        }
    }

    fn apply_cookie_counter_tier(counter: &HtmlElement, count: u32) {
        let class_list = counter.class_list();
        for tier in 0..=5 {
            let class_name = format!("cookie-clicker__counter--tier{tier}");
            let _ = class_list.remove_1(&class_name);
        }
        let tier = match count {
            0..=9 => 0,
            10..=24 => 1,
            25..=49 => 2,
            50..=74 => 3,
            75..=95 => 4,
            _ => 5,
        };
        if let Err(err) = class_list.add_1(&format!("cookie-clicker__counter--tier{tier}")) {
            utils::log(&format!(
                "Failed to update cookie counter tier class: {:?}",
                err
            ));
        }
    }

    fn apply_cookie_wrapper_state(wrapper: &HtmlElement, count: u32) {
        let class_list = wrapper.class_list();
        for class_name in [
            "cookie-clicker--warm",
            "cookie-clicker--toasty",
            "cookie-clicker--glowing",
            "cookie-clicker--celebrating",
        ] {
            let _ = class_list.remove_1(class_name);
        }
        let next_class = if count >= 100 {
            Some("cookie-clicker--celebrating")
        } else if count >= 75 {
            Some("cookie-clicker--glowing")
        } else if count >= 50 {
            Some("cookie-clicker--toasty")
        } else if count >= 25 {
            Some("cookie-clicker--warm")
        } else {
            None
        };

        if let Some(class_name) = next_class {
            if let Err(err) = class_list.add_1(class_name) {
                utils::log(&format!(
                    "Failed to update cookie wrapper class `{class_name}`: {:?}",
                    err
                ));
            }
        }
    }

    fn play_shaw_effect(&self) -> Result<(), JsValue> {
        let celebrate = {
            let mut state = self.state.borrow_mut();
            state.unlock_shaw_celebration()
        };

        if celebrate {
            self.trigger_achievement_popup(
                ACHIEVEMENT_SHAW_TITLE,
                ACHIEVEMENT_SHAW_DESCRIPTION,
                AchievementTier::Standard,
            )?;
            self.finalize_achievement_unlock()?;
        }

        self.renderer.force_scroll_to_bottom();

        let renderer = Rc::clone(&self.renderer);
        spawn_local(async move {
            // Allow the terminal to settle at the bottom before showing the effect.
            TimeoutFuture::new(120).await;

            let effect = match renderer.render_shaw_effect() {
                Ok(effect) => effect,
                Err(err) => {
                    utils::log(&format!("Failed to render Shaw effect: {:?}", err));
                    return;
                }
            };

            renderer.force_scroll_to_bottom();

            TimeoutFuture::new(3000).await;

            if let Err(err) = effect.set_attribute("data-state", "hiding") {
                utils::log(&format!(
                    "Failed to mark Shaw effect for dismissal: {:?}",
                    err
                ));
            }

            TimeoutFuture::new(260).await;

            if let Err(err) = renderer.remove_effect(&effect) {
                utils::log(&format!("Failed to remove Shaw effect: {:?}", err));
            }
        });

        Ok(())
    }

    fn ensure_input_disabled(&self) -> bool {
        let mut state = self.state.borrow_mut();
        if state.input_disabled() {
            true
        } else {
            state.set_input_disabled(true);
            false
        }
    }

    fn start_kamehameha_sequence(&self) -> Result<(), JsValue> {
        if self.ensure_input_disabled() {
            return Ok(());
        }

        self.renderer.disable_prompt_input()?;
        self.renderer.update_input("");
        self.renderer
            .render_suggestions(std::iter::empty::<(String, String)>());
        {
            let mut state = self.state.borrow_mut();
            state.prompt_label = KAMEHAMEHA_PROMPT_LABEL.to_string();
            state.input_buffer.clear();
        }
        self.renderer.set_prompt_label(KAMEHAMEHA_PROMPT_LABEL);
        self.renderer.play_konami_charge()?;

        let renderer = Rc::clone(&self.renderer);
        spawn_local(async move {
            if let Err(err) = renderer.append_info_line(KONAMI_ALERT, ScrollBehavior::Bottom) {
                utils::log(&format!("Failed to announce Konami code: {:?}", err));
            }

            TimeoutFuture::new(420).await;

            if let Err(err) = renderer.append_info_line(
                "Goku warps onto the terminal roof, palms blazing with ki.",
                ScrollBehavior::Bottom,
            ) {
                utils::log(&format!(
                    "Failed to narrate Goku's entrance into the terminal: {:?}",
                    err
                ));
            }

            renderer.force_scroll_to_bottom();

            if let Err(err) =
                renderer.append_output_html(KAMEHAMEHA_MEDIA_HTML, ScrollBehavior::Bottom)
            {
                utils::log(&format!("Failed to render Goku media: {:?}", err));
            }

            if let Err(err) = renderer.append_info_html(GOKU_FINISHER_HTML, ScrollBehavior::Bottom)
            {
                utils::log(&format!(
                    "Failed to render Goku's finishing line before the explosion: {:?}",
                    err
                ));
            }

            TimeoutFuture::new(8600).await;

            if let Err(err) = renderer.clear_konami_media() {
                utils::log(&format!(
                    "Failed to clear Kamehameha media before finishing move: {:?}",
                    err
                ));
            }

            TimeoutFuture::new(360).await;

            if let Err(err) = renderer.trigger_terminal_explosion() {
                utils::log(&format!(
                    "Failed to apply terminal explosion visuals after Konami code: {:?}",
                    err
                ));
            }

            TimeoutFuture::new(420).await;

            if let Err(err) =
                renderer.append_info_html(TERMINAL_EXPLODED_HTML, ScrollBehavior::Bottom)
            {
                utils::log(&format!(
                    "Failed to render terminal explosion aftermath message: {:?}",
                    err
                ));
            }
        });

        Ok(())
    }

    fn input_disabled(&self) -> bool {
        self.state.borrow().input_disabled()
    }

    fn is_shutdown_command(input: &str) -> bool {
        let mut normalized = String::new();
        for part in input.split_whitespace() {
            if !normalized.is_empty() {
                normalized.push(' ');
            }
            normalized.push_str(&part.to_ascii_lowercase());
        }
        normalized.contains(TV_OFF_COMMAND)
    }

    fn refresh_input(&self) {
        let buffer = { self.state.borrow().input_buffer.clone() };
        self.renderer.update_input(&buffer);
    }

    fn refresh_suggestions(&self) {
        if self.input_disabled() {
            self.renderer
                .render_suggestions(std::iter::empty::<(String, String)>());
            return;
        }
        render_current_suggestions(&self.state, &self.renderer);
    }

    pub fn toggle_suggestions_expanded(&self) {
        self.renderer.toggle_suggestions_expanded();
    }

    fn handle_ai_mode_submission(&self, input: String) -> Result<(), JsValue> {
        let normalized = input.trim().to_ascii_lowercase();
        if normalized == "help" {
            telemetry::log_command_submission(&input, CommandLogMode::Ai);
            self.renderer
                .append_output_text(AI_HELP_MESSAGE, ScrollBehavior::Bottom)?;
            return Ok(());
        }
        if normalized == "clear" {
            self.state.borrow_mut().set_ai_mode(false);
            self.renderer.clear_output();
            return self.update_ai_mode(true, false);
        }
        if normalized == "quit" {
            telemetry::log_command_submission(&input, CommandLogMode::Ai);
            return self.update_ai_mode(false, true);
        }
        self.queue_ai_answer(input)
    }

    fn queue_ai_answer(&self, question: String) -> Result<(), JsValue> {
        let data_ready = { self.state.borrow().data.is_some() };
        if !data_ready {
            self.renderer
                .append_info_line(AI_DATA_LOADING, ScrollBehavior::Bottom)?;
            return Ok(());
        }

        let (history, generation) = {
            let mut state = self.state.borrow_mut();
            if state.ai_busy {
                self.renderer.append_info_line(
                    "A response is already in progress. Type `quit` to return to classic mode.",
                    ScrollBehavior::Bottom,
                )?;
                return Ok(());
            }
            if question.trim().is_empty() || question.chars().count() > 1200 {
                self.renderer.append_info_line(
                    "Please use a question of 1–1,200 characters.",
                    ScrollBehavior::Bottom,
                )?;
                return Ok(());
            }
            state.ai_busy = true;
            (state.ai_history.clone(), state.ai_generation)
        };
        self.renderer.set_ai_indicator_text(AI_STATUS_BUSY);
        if let Err(err) = self.renderer.set_ai_busy(true) {
            utils::log(&format!("Failed to flag AI busy state: {:?}", err));
        }
        if let Err(err) = self.renderer.show_ai_loader() {
            utils::log(&format!("Failed to render AI loader: {:?}", err));
        }

        let renderer = Rc::clone(&self.renderer);
        let shared_state = Rc::clone(&self.state);

        spawn_local(async move {
            let result = ai::ask_ai(&question, &history).await;
            if shared_state.borrow().ai_generation != generation {
                return;
            }
            shared_state.borrow_mut().ai_busy = false;

            match result {
                Ok(payload) => {
                    if payload.ai_enabled {
                        {
                            let mut state = shared_state.borrow_mut();
                            state.set_ai_model(payload.model.clone());
                            state.ai_history.push(ai::Message {
                                role: "user".into(),
                                content: question.clone(),
                            });
                            state.ai_history.push(ai::Message {
                                role: "assistant".into(),
                                content: payload.answer.clone(),
                            });
                            if state.ai_history.len() > 6 {
                                state.ai_history.drain(..2);
                            }
                        }
                        render_current_suggestions(&shared_state, &renderer);
                        renderer.set_ai_indicator_text(AI_STATUS_ACTIVE);
                        if let Err(err) =
                            renderer.append_output_markdown(&payload.answer, ScrollBehavior::Bottom)
                        {
                            utils::log(&format!("Failed to render AI answer: {:?}", err));
                        }
                        if !payload.sources.is_empty() {
                            let known = [
                                "profile",
                                "skills",
                                "experience",
                                "education",
                                "projects",
                                "testimonials",
                                "faq",
                            ];
                            let labels: Vec<_> = payload
                                .sources
                                .iter()
                                .filter(|s| known.contains(&s.as_str()))
                                .cloned()
                                .collect();
                            if !labels.is_empty() {
                                let _ = renderer.append_info_line(
                                    &format!("Sources: {}", labels.join(", ")),
                                    ScrollBehavior::Bottom,
                                );
                            }
                        }
                    } else {
                        {
                            let mut state = shared_state.borrow_mut();
                            state.set_ai_model(payload.model.clone());
                            state.set_ai_mode(false);
                        }
                        if let Err(err) = renderer.apply_ai_mode(false) {
                            utils::log(&format!("Failed to revert AI mode visuals: {:?}", err));
                        }
                        renderer.set_ai_indicator_text(AI_STATUS_DEACTIVATED);
                        render_current_suggestions(&shared_state, &renderer);
                        let mut notice = payload.answer.clone();
                        if let Some(reason) = payload.reason.as_ref() {
                            notice.push_str(&format!(" ({reason})"));
                        }
                        if let Err(err) = renderer.append_info_line(&notice, ScrollBehavior::Bottom)
                        {
                            utils::log(&format!("Failed to render AI limit info: {:?}", err));
                        }
                    }
                }
                Err(error) => {
                    shared_state.borrow_mut().set_ai_mode(false);
                    let _ = renderer.apply_ai_mode(false);
                    render_current_suggestions(&shared_state, &renderer);
                    let message = format!("AI: {error}. Classic commands restored: about, experience, projects, resume.");
                    if let Err(err) = renderer.append_output_text(&message, ScrollBehavior::Bottom)
                    {
                        utils::log(&format!("Failed to render AI error: {:?}", err));
                    }
                }
            }

            if let Err(err) = renderer.set_ai_busy(false) {
                utils::log(&format!("Failed to reset AI busy state: {:?}", err));
            }
            if let Err(err) = renderer.hide_ai_loader() {
                utils::log(&format!("Failed to remove AI loader: {:?}", err));
            }

            let status = if shared_state.borrow().ai_mode {
                AI_STATUS_ACTIVE
            } else {
                AI_STATUS_DEACTIVATED
            };
            renderer.set_ai_indicator_text(status);
        });

        Ok(())
    }

    fn update_ai_mode(&self, active: bool, announce: bool) -> Result<(), JsValue> {
        let previous = {
            let mut state = self.state.borrow_mut();
            let prev = state.ai_mode;
            state.set_ai_mode(active);
            prev
        };

        if !active {
            self.renderer.hide_ai_loader()?;
        }
        self.renderer.apply_ai_mode(active)?;
        self.renderer.set_ai_indicator_text(if active {
            AI_STATUS_ACTIVE
        } else {
            AI_STATUS_DEACTIVATED
        });
        if let Err(err) = self.renderer.set_ai_busy(false) {
            utils::log(&format!("Failed to reset AI busy flag: {:?}", err));
        }

        if announce && previous != active {
            let message = if active {
                AI_ACTIVATED_INFO
            } else {
                AI_DEACTIVATED_INFO
            };
            self.renderer
                .append_info_line(message, ScrollBehavior::Bottom)?;
        }

        if previous != active {
            self.refresh_suggestions();
        }

        Ok(())
    }

    fn ai_mode_active(&self) -> bool {
        self.state.borrow().ai_mode
    }

    fn reset_konami_progress(&self) {
        let mut state = self.state.borrow_mut();
        if !state.konami_triggered {
            state.konami_index = 0;
        }
    }

    fn normalize_konami_key(key: &str) -> Option<&'static str> {
        match key {
            "ArrowUp" => Some("ArrowUp"),
            "ArrowDown" => Some("ArrowDown"),
            "ArrowLeft" => Some("ArrowLeft"),
            "ArrowRight" => Some("ArrowRight"),
            "a" | "A" => Some("a"),
            "b" | "B" => Some("b"),
            _ => None,
        }
    }
}

fn select_history_entry(state: &mut AppState, direction: HistoryDirection) -> Option<String> {
    if state.command_history.is_empty() {
        return None;
    }

    let len = state.command_history.len();

    let new_index = match (state.history_index, direction) {
        (None, HistoryDirection::Older) => Some(len - 1),
        (None, HistoryDirection::Newer) => None,
        (Some(0), HistoryDirection::Older) => Some(0),
        (Some(idx), HistoryDirection::Older) => Some(idx.saturating_sub(1)),
        (Some(idx), HistoryDirection::Newer) => {
            if idx + 1 >= len {
                None
            } else {
                Some(idx + 1)
            }
        }
    };

    state.history_index = new_index;

    let buffer = match new_index {
        Some(idx) => state.command_history[idx].clone(),
        None => String::new(),
    };

    state.input_buffer = buffer.clone();
    Some(buffer)
}

const HIDDEN_HELPER_COMMANDS: [&str; 3] = ["shaw", "pokemon", "cookie"];

fn is_hidden_helper(command: &str) -> bool {
    HIDDEN_HELPER_COMMANDS
        .iter()
        .any(|hidden| hidden.eq_ignore_ascii_case(command))
}

fn default_suggestions() -> Vec<&'static str> {
    let mut names: Vec<&'static str> = commands::command_names()
        .into_iter()
        .filter(|name| !is_hidden_helper(name))
        .collect();
    if let Some(index) = names.iter().position(|name| *name == "resume") {
        let resume = names.remove(index);
        names.insert(0, resume);
    }
    if let Some(index) = names.iter().position(|name| *name == "contact") {
        let contact = names.remove(index);
        let insert_at = if names.is_empty() { 0 } else { 1 };
        names.insert(insert_at, contact);
    }
    names
}

fn ai_help_label(model: Option<&str>) -> String {
    match model {
        Some(name) if !name.trim().is_empty() => format!("AI help ({name})"),
        _ => "AI help".to_string(),
    }
}

fn ai_mode_suggestions(filter: &str, model: Option<&str>) -> Vec<(String, String)> {
    let commands = [
        (AI_HELP_COMMAND, ai_help_label(model)),
        (AI_QUIT_COMMAND, AI_QUIT_LABEL.to_string()),
    ];

    commands
        .into_iter()
        .filter(|(command, _)| filter.is_empty() || command.starts_with(filter))
        .map(|(command, label)| ((*command).to_string(), label))
        .collect()
}

fn render_current_suggestions(state: &SharedState, renderer: &SharedRenderer) {
    let (buffer, ai_mode, ai_model) = {
        let state = state.borrow();
        (
            state.input_buffer.clone(),
            state.ai_mode,
            state.ai_model.clone(),
        )
    };
    let trimmed = buffer.trim().to_ascii_lowercase();

    let suggestions: Vec<(String, String)> = if ai_mode {
        ai_mode_suggestions(&trimmed, ai_model.as_deref())
    } else {
        let names: Vec<String> = if trimmed.is_empty() {
            default_suggestions()
                .into_iter()
                .map(|s| s.to_string())
                .collect()
        } else {
            commands::suggestions(&buffer)
                .into_iter()
                .filter(|name| !is_hidden_helper(name))
                .map(|s| s.to_string())
                .collect()
        };

        names
            .into_iter()
            .filter(|command| !is_hidden_helper(command))
            .map(|command| {
                let label = commands::helper_label(&command);
                (command, label)
            })
            .collect()
    };

    renderer.render_suggestions(suggestions);
}

fn profile_loaded_line(name: &str) -> String {
    format!("Profile loaded for {}.", name)
}

#[derive(Debug, Serialize, Deserialize)]
struct StoredAchievements {
    version: String,
    shaw: bool,
    pokemon: bool,
    #[serde(default)]
    cookie: bool,
    konami: bool,
    shutdown: bool,
    #[serde(default)]
    platinum: bool,
    spoilers_enabled: bool,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::state::{
        Education, Experience, FaqEntry, Profile, ProfileLinks, ProjectsCollection, ResumeVariant,
        TerminalData, Testimonial,
    };
    use wasm_bindgen_test::wasm_bindgen_test;

    fn make_state_with_data() -> AppState {
        use std::collections::BTreeMap;

        let mut state = AppState::new();
        let profile = Profile {
            name: "Alex".to_string(),
            headline: "Rustacean".to_string(),
            summary_fr: None,
            summary_en: None,
            location: None,
            email: None,
            links: ProfileLinks {
                github: None,
                linkedin: None,
                website: None,
                resume_url: Some("https://founding.zqsdev.com".to_string()),
            },
            resume_variants: vec![ResumeVariant {
                id: "founding".to_string(),
                label: "Founding Engineer".to_string(),
                url: "https://founding.zqsdev.com/".to_string(),
            }],
            languages: None,
        };

        let data = TerminalData::new(
            profile,
            BTreeMap::new(),
            Vec::<Experience>::new(),
            Vec::<Education>::new(),
            ProjectsCollection::default(),
            Vec::<Testimonial>::new(),
            Vec::<FaqEntry>::new(),
        );
        state.set_data(data);
        state
    }

    #[test]
    fn boot_sequence_matches_spec() {
        assert_eq!(
            super::BOOT_SEQUENCE_MESSAGE,
            "Welcome to the ZQSDev interactive terminal!"
        );
    }

    #[test]
    fn guidance_lines_match_spec() {
        assert_eq!(
            super::WELCOME_GUIDANCE_LINES,
            [
                "Type `help` to view all available commands.",
                "Use the quick actions below to jump to key sections instantly."
            ]
        );
    }

    #[test]
    fn profile_loaded_line_formats_name() {
        assert_eq!(
            super::profile_loaded_line("Alex"),
            "Profile loaded for Alex."
        );
    }

    #[wasm_bindgen_test]
    fn default_suggestions_execute_without_errors() {
        let state = make_state_with_data();
        let mut expected = crate::commands::command_names();
        expected.retain(|name| !super::is_hidden_helper(name));
        if let Some(index) = expected.iter().position(|name| *name == "resume") {
            let resume = expected.remove(index);
            expected.insert(0, resume);
        }
        if let Some(index) = expected.iter().position(|name| *name == "contact") {
            let contact = expected.remove(index);
            let insert_at = if expected.is_empty() { 0 } else { 1 };
            expected.insert(insert_at, contact);
        }
        assert_eq!(
            super::default_suggestions(),
            expected,
            "Default suggestions should list every command with résumé/contact helpers prioritised"
        );
        for command in super::default_suggestions() {
            let result = crate::commands::execute(command, &state, &[]);
            assert!(
                result.is_ok(),
                "Suggestion `{command}` should execute without errors"
            );
        }
    }

    #[wasm_bindgen_test]
    fn resume_helper_chip_is_prioritized() {
        let suggestions = super::default_suggestions();
        assert_eq!(
            suggestions.first().copied(),
            Some("resume"),
            "Résumé helper chip should be the first suggestion"
        );
    }

    #[test]
    fn ai_help_label_includes_model_name() {
        let label = super::ai_help_label(Some("gpt-4o-mini"));
        assert!(
            label.contains("gpt-4o-mini"),
            "AI help label should include the model name: {label}"
        );
    }

    #[test]
    fn ai_mode_suggestions_label_help_with_model() {
        let suggestions = super::ai_mode_suggestions("", Some("llama-3.1-8b-instant"));
        let help = suggestions
            .iter()
            .find(|(command, _)| command == "help")
            .expect("help suggestion missing");
        assert!(
            help.1.contains("llama-3.1-8b-instant"),
            "Help label should mention the active model {help:?}"
        );
    }

    #[test]
    fn ai_mode_suggestions_filter_by_prefix() {
        let suggestions = super::ai_mode_suggestions("q", Some("gpt"));
        assert_eq!(
            suggestions.len(),
            1,
            "Only the quit suggestion should match prefix `q`"
        );
        assert_eq!(suggestions[0].0, "quit");
    }

    #[test]
    fn achievement_views_include_platinum_entry() {
        let state = AppState::new();
        let achievements = super::Terminal::build_achievement_views(&state);

        assert_eq!(achievements.len(), 6);
        assert_eq!(
            achievements
                .last()
                .map(|achievement| achievement.title.as_str()),
            Some(super::ACHIEVEMENT_PLATINUM_TITLE)
        );
    }

    #[test]
    fn achievement_views_promote_unlocked_platinum_into_unlocked_section() {
        let mut state = AppState::new();
        state.achievement_shaw_unlocked = true;
        state.achievement_pokemon_unlocked = true;
        state.achievement_cookie_unlocked = true;
        state.achievement_konami_unlocked = true;
        state.achievement_shutdown_unlocked = true;
        state.achievement_platinum_unlocked = true;

        let achievements = super::Terminal::build_achievement_views(&state);
        assert_eq!(
            achievements
                .first()
                .map(|achievement| achievement.title.as_str()),
            Some(super::ACHIEVEMENT_SHAW_TITLE)
        );
        assert!(achievements
            .iter()
            .take_while(|achievement| achievement.unlocked)
            .any(|achievement| achievement.title == super::ACHIEVEMENT_PLATINUM_TITLE));
    }

    #[wasm_bindgen_test]
    fn history_navigation_updates_input_buffer() {
        let mut state = AppState::new();
        state.command_history.push("help".to_string());
        state.command_history.push("faq".to_string());

        let newest = super::select_history_entry(&mut state, HistoryDirection::Older)
            .expect("history should produce newest command");
        assert_eq!(newest, "faq");
        assert_eq!(state.input_buffer, "faq");
        assert_eq!(state.history_index, Some(1));

        let older = super::select_history_entry(&mut state, HistoryDirection::Older)
            .expect("history should produce older command");
        assert_eq!(older, "help");
        assert_eq!(state.input_buffer, "help");
        assert_eq!(state.history_index, Some(0));

        let newer = super::select_history_entry(&mut state, HistoryDirection::Newer)
            .expect("history should move forward");
        assert_eq!(newer, "faq");
        assert_eq!(state.input_buffer, "faq");
        assert_eq!(state.history_index, Some(1));

        let exit = super::select_history_entry(&mut state, HistoryDirection::Newer)
            .expect("history should exit to empty buffer");
        assert_eq!(exit, "");
        assert_eq!(state.input_buffer, "");
        assert_eq!(state.history_index, None);
    }
}
